import requests

headers = {
    'X-Requested-By': 'sdc',
}

response = requests.post('http://10.160.3.12:18630/rest/v1/pipeline/CDOMktCloudLoadForaEscopod5583631-c354-4b25-bdff-7b512413ac6c/start', headers=headers, auth=('admin', 'admin'))
