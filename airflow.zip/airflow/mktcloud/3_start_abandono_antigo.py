import requests

headers = {
    'X-Requested-By': 'sdc',
}

response = requests.post('http://10.160.3.12:18630/rest/v1/pipeline/CDOMktCloudLoadV425a69660-f4d3-4467-a0ac-7a47c479f032/start', headers=headers, auth=('admin', 'admin'))
