print("Iniciando processo do MKT Cloud no StreamSets!")
