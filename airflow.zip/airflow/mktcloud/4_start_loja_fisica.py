import requests

headers = {
    'X-Requested-By': 'sdc',
}

response = requests.post('http://10.160.3.12:18630/rest/v1/pipeline/CDOMktCloudLoadV5f5fda25d-6d10-48bb-be28-882e36e71c40/start', headers=headers, auth=('admin', 'admin'))
