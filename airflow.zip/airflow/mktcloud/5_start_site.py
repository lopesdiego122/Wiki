import requests

headers = {
    'X-Requested-By': 'sdc',
}

response = requests.post('http://10.160.3.12:18630/rest/v1/pipeline/CDOMktCloudLoadV60c1e8dcd-e01f-41a7-8dfa-72d989b5e85b/start', headers=headers, auth=('admin', 'admin'))
