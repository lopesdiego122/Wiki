# ***************************************************************
# DAG Dinamica - Configuracao arquivo.yml
# Dag base......: 25/11/2019  fabiots
# Data Criacao..: 25/11/2019  lucasvis
# Versao 1.0....: 25/11/2019  lucasvis - arquivo.yml
# Versao 1.1....: 26/11/2019  lucasvis - BashOperator StreamSets
# Versao 1.2....: 10/12/2019  lucasvis - BashOperator Pentaho
# Versao 1.3....: 20/12/2019  lucasvis - Parametro Repositorio
# ***************************************************************

# Importando as bibliotecas

from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.operators.bash_operator import BashOperator
from datetime import datetime, timedelta
import yaml
import requests
import sys


def streamsets(vCod):
    headers = {
        'X-Requested-By': 'sdc',
    }
    response = requests.post('http://10.160.3.12:18630/rest/v1/pipeline/'+vCod+'/start',
    headers=headers, auth=('admin', 'admin'))
    return headers


dagConfig = yaml.safe_load(open('/usr/local/airflow/dags/config/campanhas.yml').read())

def represent_none(self, _):
    return self.represent_scalar('tag:yaml.org,2002:null', '')

yaml.add_representer(type(None), represent_none)

default_args = {
    'owner': 'airflow',
    'depends_on_past': True
}

dag = DAG(dagConfig['dagname'],
          description=dagConfig['description'],
          schedule_interval=dagConfig['schedule_interval'],
          start_date=datetime(2020, 1, 16),
          default_args=default_args,
          catchup=False)

tasks = {}

start = DummyOperator(task_id='start', dag=dag)
tasks['start'] = start

for job, jobtasks in dagConfig["etlflow"].items():
    for task, task_properties in jobtasks.items():

        if task_properties['tasktype'] == 'DummyOperator':
            operator_task = DummyOperator(
                task_id = task_properties['task_id']
            )        
        elif task_properties['tasktype'] == 'PentahoTransformation':
            operator_task = BashOperator(
                task_id = task_properties['task_id'],
                bash_command ="""
                ssh root@10.41.21.16 sh /work/pentaho/scheduler/pentaho.sh tr campanhas """+task_properties['command']
            )        
        elif task_properties['tasktype'] == 'PentahoJob':
            operator_task = BashOperator(
                task_id = task_properties['task_id'],
                bash_command ="""
                ssh root@10.41.21.16 sh /work/pentaho/scheduler/pentaho.sh jb campanhas """+task_properties['command']
            )        
        elif task_properties['tasktype'] == 'BashOperator':
            operator_task = BashOperator(
                task_id = task_properties['task_id'],
                bash_command = task_properties['command']
            )
        elif task_properties['tasktype'] == 'PythonOperator':        
            operator_task = PythonOperator(
                task_id = task_properties['task_id'],
                python_callable = task_properties['command'],
                op_args = task_properties['op_args']
            )
        elif task_properties['tasktype'] == 'StreamSets':
            operator_task = PythonOperator(
                task_id = task_properties['task_id'],
                python_callable = streamsets,
                op_args = task_properties['op_args']
            )
        else:
            print('Operador Invalido!')
            
        tasks[task_properties['task_id']] = operator_task

        if task_properties['depends_on_task'] != None:
            tasksDepends = task_properties['depends_on_task']
            for taskDepends in tasksDepends:
                operator_task.set_upstream(tasks[taskDepends])
        else:
            operator_task.set_upstream(start)
