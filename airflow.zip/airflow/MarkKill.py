# ***************************************************************
# DAG Mark kill - Encerra processos dessincronizados entre o
# Airflow e o host Linux
# Data Criacao..: 02/03/2020  lucasvis
# ***************************************************************
from airflow import DAG
from datetime import datetime, timedelta
from airflow.operators.bash_operator import BashOperator

default_args = {
   'owner': 'airflow',
   'depends_on_past': False,
   'start_date': datetime(2020, 3, 2)
   }

with DAG(
    'Processos',
    schedule_interval='0 2 * * *',
    catchup=True,
    default_args=default_args
    ) as dag:

    kill = BashOperator(
        task_id='Mark_Kill',
        bash_command="""
        ssh root@10.41.21.16 python /work/pentaho/scheduler/AirflowPid.py
        """)
kill
