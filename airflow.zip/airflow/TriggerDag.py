# ***************************************************************
# Trigger DAG Dinamica
# Data Criacao..: 11/03/2020  lucasvis
# Versao 1.0....: 11/03/2020  lucasvis Gatilho que executa DAG
# com politica de horario definido no yml. Variacao de 10min.
# ***************************************************************
from airflow import DAG
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.dagrun_operator import TriggerDagRunOperator
from functools import partial
from datetime import datetime
import yaml
import sys

vTm=int(datetime.today().strftime('%H%M'))
vTv=10
dagConfig = yaml.safe_load(open('/usr/local/airflow/dags/config/triggerdag.yml').read())

def represent_none(self, _):
    return self.represent_scalar('tag:yaml.org,2002:null', '')

yaml.add_representer(type(None), represent_none)

args = {
    'owner': 'airflow',
    'depends_on_past': True
}

dag = DAG(dagConfig['dagname'],
          description=dagConfig['description'],
          schedule_interval=dagConfig['schedule_interval'],
          start_date=datetime(2020, 3, 10),
          default_args=args,
          catchup=False)

tasks = {}

start = DummyOperator(task_id='start', dag=dag)
tasks['start'] = start


for job, jobtasks in dagConfig["etlflow"].items():
    for task, task_properties in jobtasks.items():

        if task_properties['schedule_task'] >= (vTm-vTv):
            if task_properties['schedule_task'] <= (vTm+vTv):
                operator_task = TriggerDagRunOperator(
                    task_id=task_properties['task_id'],
                    trigger_dag_id=task_properties['trigger_dag_id'],
                    dag=dag
                )
            else:
                operator_task = DummyOperator(
                    task_id=task_properties['task_id']
            )
        else:
            operator_task = DummyOperator(
                task_id=task_properties['task_id']
            )
            
        tasks[task_properties['task_id']] = operator_task

        operator_task.set_upstream(start)

