# ***************************************************************
# DAG
# Data Criacao..: 11/11/2019  lucasvis
# ***************************************************************

# Importando as bibliotecas

from airflow import DAG
from datetime import datetime, timedelta
from airflow.operators.bash_operator import BashOperator
# Definindo alguns argumentos básicos
default_args = {
   'owner': 'airflow',
   'depends_on_past': False,
   'start_date': datetime(2019, 11, 29)
   }
# DAG
with DAG(
    'StreamSets_MKTCloud',
    schedule_interval='0 23 * * *',
    catchup=True,
    default_args=default_args
    ) as dag:
# Tarefas da DAG
    t1 = BashOperator(
        task_id='Inicio',
        bash_command="""
        cd $AIRFLOW_HOME/dags/mktcloud/
        python3 1_init_mkt.py
        """)
    t2 = BashOperator(
        task_id='abandono_novo',
        bash_command="""
        cd $AIRFLOW_HOME/dags/mktcloud/
        python3 2_start_abandono_novo.py
        """)
    t3 = BashOperator(
        task_id='Wait',
        bash_command='sleep 50m')
    t4 = BashOperator(
        task_id='abandono_antigo',
        bash_command="""
        cd $AIRFLOW_HOME/dags/mktcloud/
        python3 3_start_abandono_antigo.py
        """)
    t5 = BashOperator(
        task_id='loja_fisica',
        bash_command="""
        cd $AIRFLOW_HOME/dags/mktcloud/
        python3 4_start_loja_fisica.py
        """)
    t6 = BashOperator(
        task_id='site',
        bash_command="""
        cd $AIRFLOW_HOME/dags/mktcloud/
        python3 5_start_site.py
        """)
    t7 = BashOperator(
        task_id='fora_scopo',
        bash_command="""
        cd $AIRFLOW_HOME/dags/mktcloud/
        python3 6_start_fora_scopo.py
        """)

# Ordem das tarefas
t1 >> t2 >> t3 >> t4 >> t5 >> t6 >> t7

