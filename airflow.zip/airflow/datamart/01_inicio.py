print("Iniciando o processo do DataMart!")
